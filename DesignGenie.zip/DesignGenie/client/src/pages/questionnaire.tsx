import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { ProgressBar } from "@/components/progress-bar";
import { QuestionnaireStep } from "@/components/questionnaire-step";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Sparkles, Info } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { DesignProjectForm } from "@shared/schema";

export default function Questionnaire() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<Partial<DesignProjectForm>>({});

  const createProjectMutation = useMutation({
    mutationFn: async (data: DesignProjectForm) => {
      const response = await apiRequest("POST", "/api/design-projects", data);
      return response.json();
    },
    onSuccess: (project) => {
      setLocation(`/results/${project.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create project. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateFormData = (newData: Partial<DesignProjectForm>) => {
    setFormData(prev => ({ ...prev, ...newData }));
  };

  const handleNext = () => {
    if (currentStep < 6) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    } else {
      setLocation("/");
    }
  };

  const handleGenerate = () => {
    if (!isFormValid()) {
      toast({
        title: "Please complete required fields",
        description: "Project name, type, style, and color preferences are required.",
        variant: "destructive",
      });
      return;
    }

    createProjectMutation.mutate(formData as DesignProjectForm);
  };

  const isStepValid = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!formData.projectType;
      case 2:
        return !!formData.style;
      case 3:
        return !!formData.projectName;
      case 4:
        return !!formData.colors;
      default:
        return true;
    }
  };

  const isFormValid = (): boolean => {
    return !!(
      formData.projectName &&
      formData.projectType &&
      formData.style &&
      formData.colors
    );
  };

  const renderReviewStep = () => {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Review your design brief</h3>
          <p className="text-gray-600">Please review your answers before generating your custom design</p>
        </div>
        
        <div className="space-y-6" data-testid="review-content">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Project Type</h5>
                <p className="text-gray-700 capitalize" data-testid="review-project-type">
                  {formData.projectType || 'Not specified'}
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Style Preference</h5>
                <p className="text-gray-700 capitalize" data-testid="review-style">
                  {formData.style || 'Not specified'}
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Color Scheme</h5>
                <p className="text-gray-700 capitalize" data-testid="review-colors">
                  {formData.colors || 'Not specified'}
                </p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Project Name</h5>
                <p className="text-gray-700" data-testid="review-project-name">
                  {formData.projectName || 'Untitled Project'}
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Vision</h5>
                <p className="text-gray-700" data-testid="review-description">
                  {formData.description || 'No description provided'}
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Budget & Timeline</h5>
                <p className="text-gray-700" data-testid="review-budget-timeline">
                  {formData.budget || 'Not specified'} • {formData.timeline || 'Flexible'}
                </p>
              </div>
            </div>
          </div>
          
          {formData.features && formData.features.length > 0 && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h5 className="font-semibold text-gray-900 mb-2">Selected Features</h5>
              <div className="flex flex-wrap gap-2" data-testid="review-features">
                {formData.features.map((feature, index) => (
                  <span key={index} className="px-3 py-1 bg-primary text-white text-sm rounded-full">
                    {(feature as string).replace('-', ' ')}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {formData.additionalNotes && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h5 className="font-semibold text-gray-900 mb-2">Additional Notes</h5>
              <p className="text-gray-700" data-testid="review-additional-notes">
                {formData.additionalNotes}
              </p>
            </div>
          )}
        </div>
        
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mt-8">
          <div className="flex items-start">
            <Info className="text-blue-500 mt-1 mr-3" />
            <div>
              <h4 className="font-semibold text-blue-900 mb-1">Ready to generate your design?</h4>
              <p className="text-blue-700 text-sm">
                Our AI will create a unique design based on your preferences. This process typically takes 30-60 seconds.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between mt-8">
          <Button variant="ghost" onClick={handlePrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back to Edit
          </Button>
          <Button 
            onClick={handleGenerate}
            disabled={createProjectMutation.isPending || !isFormValid()}
            className="bg-gradient-to-r from-primary to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-8 shadow-lg hover:shadow-xl"
            data-testid="button-generate-design"
          >
            {createProjectMutation.isPending ? (
              <>Generating...</>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate My Design
              </>
            )}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                <Sparkles className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                <p className="text-xs text-gray-500">AI Design Generator</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <ProgressBar currentStep={currentStep} totalSteps={6} />
        </div>

        {/* Questionnaire Steps */}
        {currentStep <= 5 ? (
          <QuestionnaireStep
            step={currentStep}
            formData={formData}
            updateFormData={updateFormData}
            onNext={handleNext}
            onPrev={handlePrev}
            isValid={isStepValid(currentStep)}
          />
        ) : (
          renderReviewStep()
        )}
      </main>
    </div>
  );
}
