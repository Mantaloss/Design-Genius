import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, Share, RefreshCw, Plus, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { DesignProject } from "@shared/schema";

export default function Results() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: project, isLoading } = useQuery<DesignProject>({
    queryKey: ["/api/design-projects", id],
    enabled: !!id,
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/design-projects/${id}/generate`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/design-projects", id] });
      toast({
        title: "Design Generated!",
        description: "Your custom design has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate design. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="text-white text-lg" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                  <p className="text-xs text-gray-500">AI Design Generator</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <Skeleton className="h-8 w-64 mb-4" />
              <Skeleton className="h-64 w-full" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Project not found</h2>
          <p className="text-gray-600 mb-4">The project you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation("/")} data-testid="button-go-home">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  // Show loading state during generation
  if (generateMutation.isPending) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="text-white text-lg" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                  <p className="text-xs text-gray-500">AI Design Generator</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm p-12 text-center" data-testid="loading-state">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-full mb-4 animate-pulse">
                <Sparkles className="text-white text-2xl" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Creating your design...</h3>
              <p className="text-gray-600">Our AI is analyzing your preferences and generating a custom design</p>
            </div>
            
            <div className="max-w-md mx-auto">
              <div className="flex justify-between text-sm text-gray-500 mb-2">
                <span>Processing</span>
                <span>Generating...</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gradient-to-r from-primary to-purple-600 h-2 rounded-full animate-pulse w-3/4" />
              </div>
              <div className="mt-4 text-sm text-gray-500">
                <div className="font-medium">Analyzing your preferences...</div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Show generate button if no design has been generated yet
  if (!project.generatedImageUrl) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="text-white text-lg" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                  <p className="text-xs text-gray-500">AI Design Generator</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Ready to Generate Your Design</h2>
            <p className="text-gray-600 mb-8">
              Your project "{project.projectName}" is ready. Click the button below to generate your custom design.
            </p>
            <Button 
              onClick={() => generateMutation.mutate()}
              size="lg"
              className="bg-gradient-to-r from-primary to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-4 px-8 text-lg shadow-lg hover:shadow-xl"
              data-testid="button-generate-design"
            >
              <Sparkles className="mr-2" />
              Generate My Design
            </Button>
          </div>
        </main>
      </div>
    );
  }

  // Show the generated design results
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                <Sparkles className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                <p className="text-xs text-gray-500">AI Design Generator</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-8" data-testid="results-section">
          {/* Generated Design */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-1">Your Custom Design</h3>
                  <p className="text-gray-600">Generated based on your preferences</p>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" data-testid="button-download">
                    <Download className="w-4 h-4 mr-2" />Download
                  </Button>
                  <Button variant="outline" size="sm" data-testid="button-share">
                    <Share className="w-4 h-4 mr-2" />Share
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="aspect-video bg-gray-100">
              <img 
                src={project.generatedImageUrl} 
                alt="Generated design" 
                className="w-full h-full object-cover"
                data-testid="generated-image"
              />
            </div>
          </div>

          {/* Design Description */}
          {project.designDescription && (
            <div className="bg-white rounded-lg shadow-sm p-8">
              <h4 className="text-xl font-bold text-gray-900 mb-4">Design Concept</h4>
              <div className="prose prose-gray max-w-none" data-testid="design-description">
                <p className="text-gray-700 whitespace-pre-wrap">{project.designDescription}</p>
              </div>
            </div>
          )}

          {/* Design Details */}
          {project.designExplanation && (
            <div className="bg-white rounded-lg shadow-sm p-8">
              <h4 className="text-xl font-bold text-gray-900 mb-4">How This Design Meets Your Requirements</h4>
              <div className="text-gray-700 whitespace-pre-wrap" data-testid="design-explanation">
                {project.designExplanation}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-center space-x-4">
            <Button 
              variant="outline"
              onClick={() => generateMutation.mutate()}
              disabled={generateMutation.isPending}
              data-testid="button-generate-another"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Generate Another Design
            </Button>
            <Button 
              onClick={() => setLocation("/")}
              data-testid="button-start-new-project"
            >
              <Plus className="w-4 h-4 mr-2" />
              Start New Project
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
