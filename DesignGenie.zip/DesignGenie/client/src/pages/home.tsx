import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Sparkles } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                <Sparkles className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">DesignGenius</h1>
                <p className="text-xs text-gray-500">AI Design Generator</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-500 hover:text-gray-700">
                <i className="fas fa-question-circle"></i>
                <span className="ml-1 text-sm">Help</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <div className="mb-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Create Your Perfect Design</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Answer a few questions about your vision, and our AI will generate stunning, personalized designs for your architectural, interior, or artistic projects.
            </p>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-md mx-auto mb-8">
            <div>
              <div className="text-2xl font-bold text-primary">10K+</div>
              <div className="text-sm text-gray-500">Designs Generated</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary">2-3min</div>
              <div className="text-sm text-gray-500">Quick Process</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary">98%</div>
              <div className="text-sm text-gray-500">Satisfaction Rate</div>
            </div>
          </div>

          <Button 
            onClick={() => setLocation("/questionnaire")}
            size="lg"
            className="bg-primary hover:bg-blue-700 text-white font-semibold py-4 px-8 text-lg shadow-lg hover:shadow-xl"
            data-testid="button-start-questionnaire"
          >
            <Sparkles className="mr-2" />
            Start Creating Your Design
          </Button>
        </div>
      </main>
    </div>
  );
}
