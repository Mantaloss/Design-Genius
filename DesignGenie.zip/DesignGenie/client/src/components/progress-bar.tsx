interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function ProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  const progressPercentage = (currentStep / totalSteps) * 100;
  
  const stepLabels = [
    "Project Type",
    "Style", 
    "Details",
    "Colors",
    "Features",
    "Review"
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-700">Progress</span>
        <span data-testid="progress-text" className="text-sm text-gray-500">
          Step {currentStep} of {totalSteps}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          data-testid="progress-bar"
          className="bg-gradient-to-r from-primary to-purple-600 h-2 rounded-full transition-all duration-300" 
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
      <div className="flex justify-between mt-2 text-xs text-gray-400">
        {stepLabels.map((label, index) => (
          <span key={index} className={index < currentStep ? "text-primary" : ""}>
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}
