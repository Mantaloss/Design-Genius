import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, Building, Sofa, TreePine, Box, Palette, House, Square, Church, Settings, Minus, Leaf, Rocket } from "lucide-react";

interface QuestionnaireStepProps {
  step: number;
  formData: any;
  updateFormData: (data: any) => void;
  onNext: () => void;
  onPrev: () => void;
  isValid: boolean;
}

export function QuestionnaireStep({ step, formData, updateFormData, onNext, onPrev, isValid }: QuestionnaireStepProps) {
  
  const handleOptionSelect = (field: string, value: string) => {
    updateFormData({ [field]: value });
  };

  const handleFeatureToggle = (feature: string, checked: boolean) => {
    const currentFeatures = formData.features || [];
    const updatedFeatures = checked 
      ? [...currentFeatures, feature]
      : currentFeatures.filter((f: string) => f !== feature);
    updateFormData({ features: updatedFeatures });
  };

  if (step === 1) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">What type of project are you working on?</h3>
          <p className="text-gray-600">Select the category that best describes your project</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {[
            { value: "architecture", icon: Building, title: "Architecture", description: "Buildings, structures, exteriors" },
            { value: "interior", icon: Sofa, title: "Interior Design", description: "Rooms, spaces, furniture layouts" },
            { value: "landscape", icon: TreePine, title: "Landscape", description: "Gardens, outdoor spaces, parks" },
            { value: "product", icon: Box, title: "Product Design", description: "Industrial, furniture, objects" },
            { value: "artistic", icon: Palette, title: "Artistic Concept", description: "Abstract, conceptual, artistic" },
            { value: "urban", icon: House, title: "Urban Planning", description: "House layouts, public spaces" },
          ].map((option) => {
            const Icon = option.icon;
            const isSelected = formData.projectType === option.value;
            return (
              <label 
                key={option.value}
                className="cursor-pointer"
                data-testid={`option-project-type-${option.value}`}
              >
                <input 
                  type="radio" 
                  name="project-type" 
                  value={option.value} 
                  className="hidden"
                  onChange={(e) => handleOptionSelect("projectType", e.target.value)}
                />
                <div className={`border-2 rounded-lg p-6 text-center hover:border-primary hover:bg-blue-50 transition-all duration-200 ${
                  isSelected ? "border-primary bg-blue-50" : "border-gray-200"
                }`}>
                  <Icon className="w-8 h-8 text-gray-400 mb-3 mx-auto" />
                  <h4 className="font-semibold text-gray-900">{option.title}</h4>
                  <p className="text-sm text-gray-500">{option.description}</p>
                </div>
              </label>
            );
          })}
        </div>
        
        <div className="flex justify-between">
          <Button variant="ghost" onClick={onPrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <Button onClick={onNext} disabled={!isValid} data-testid="button-next">
            Next <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">What's your preferred style?</h3>
          <p className="text-gray-600">Choose the aesthetic that resonates with your vision</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {[
            { value: "modern", icon: Square, title: "Modern/Contemporary", description: "Clean lines, minimal, sleek" },
            { value: "traditional", icon: Church, title: "Traditional/Classic", description: "Timeless, elegant, ornate" },
            { value: "industrial", icon: Settings, title: "Industrial", description: "Raw materials, exposed elements" },
            { value: "minimalist", icon: Minus, title: "Minimalist", description: "Simple, uncluttered, essential" },
            { value: "organic", icon: Leaf, title: "Organic/Natural", description: "Curved lines, natural materials" },
            { value: "futuristic", icon: Rocket, title: "Futuristic", description: "Innovative, high-tech, avant-garde" },
          ].map((option) => {
            const Icon = option.icon;
            const isSelected = formData.style === option.value;
            return (
              <label 
                key={option.value}
                className="cursor-pointer"
                data-testid={`option-style-${option.value}`}
              >
                <input 
                  type="radio" 
                  name="style" 
                  value={option.value} 
                  className="hidden"
                  onChange={(e) => handleOptionSelect("style", e.target.value)}
                />
                <div className={`border-2 rounded-lg p-6 hover:border-primary hover:bg-blue-50 transition-all duration-200 ${
                  isSelected ? "border-primary bg-blue-50" : "border-gray-200"
                }`}>
                  <div className="flex items-center mb-3">
                    <Icon className="w-6 h-6 text-gray-400 mr-3" />
                    <h4 className="font-semibold text-gray-900">{option.title}</h4>
                  </div>
                  <p className="text-sm text-gray-500">{option.description}</p>
                </div>
              </label>
            );
          })}
        </div>
        
        <div className="flex justify-between">
          <Button variant="ghost" onClick={onPrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <Button onClick={onNext} disabled={!isValid} data-testid="button-next">
            Next <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Tell us about your project</h3>
          <p className="text-gray-600">Provide details to help us create the perfect design</p>
        </div>
        
        <div className="space-y-6">
          <div>
            <Label className="text-sm font-semibold text-gray-700 mb-2">Project Name</Label>
            <Input 
              value={formData.projectName || ""}
              onChange={(e) => updateFormData({ projectName: e.target.value })}
              placeholder="e.g., Modern Beach House, Office Redesign"
              data-testid="input-project-name"
            />
          </div>
          
          <div>
            <Label className="text-sm font-semibold text-gray-700 mb-2">Describe your vision</Label>
            <Textarea 
              value={formData.description || ""}
              onChange={(e) => updateFormData({ description: e.target.value })}
              rows={4}
              placeholder="Tell us about your ideal design. What feeling should it evoke? What are the key elements you envision?"
              data-testid="textarea-description"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-semibold text-gray-700 mb-2">Budget Range</Label>
              <Select 
                value={formData.budget || ""} 
                onValueChange={(value) => updateFormData({ budget: value })}
              >
                <SelectTrigger data-testid="select-budget">
                  <SelectValue placeholder="Select budget range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Under $50K</SelectItem>
                  <SelectItem value="medium">$50K - $200K</SelectItem>
                  <SelectItem value="high">$200K - $500K</SelectItem>
                  <SelectItem value="luxury">$500K+</SelectItem>
                  <SelectItem value="concept">Concept only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-sm font-semibold text-gray-700 mb-2">Timeline</Label>
              <Select 
                value={formData.timeline || ""} 
                onValueChange={(value) => updateFormData({ timeline: value })}
              >
                <SelectTrigger data-testid="select-timeline">
                  <SelectValue placeholder="Select timeline" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">ASAP</SelectItem>
                  <SelectItem value="month">Within a month</SelectItem>
                  <SelectItem value="quarter">3 months</SelectItem>
                  <SelectItem value="half-year">6 months</SelectItem>
                  <SelectItem value="year">1+ year</SelectItem>
                  <SelectItem value="flexible">Flexible</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-semibold text-gray-700 mb-2">Special Requirements</Label>
            <Textarea 
              value={formData.specialRequirements || ""}
              onChange={(e) => updateFormData({ specialRequirements: e.target.value })}
              rows={3}
              placeholder="Any specific requirements, constraints, or must-have elements?"
              data-testid="textarea-special-requirements"
            />
          </div>
        </div>
        
        <div className="flex justify-between mt-8">
          <Button variant="ghost" onClick={onPrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <Button onClick={onNext} data-testid="button-next">
            Next <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  if (step === 4) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">What's your color preference?</h3>
          <p className="text-gray-600">Choose a color palette that reflects your vision</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {[
            { 
              value: "neutral", 
              title: "Neutral & Calm", 
              description: "Whites, grays, beiges, earth tones",
              colors: ["bg-gray-300", "bg-gray-600", "bg-white border"]
            },
            { 
              value: "warm", 
              title: "Warm & Energetic", 
              description: "Reds, oranges, yellows, warm browns",
              colors: ["bg-red-400", "bg-orange-400", "bg-yellow-400"]
            },
            { 
              value: "cool", 
              title: "Cool & Serene", 
              description: "Blues, greens, purples, cool grays",
              colors: ["bg-blue-400", "bg-green-400", "bg-purple-400"]
            },
            { 
              value: "bold", 
              title: "Bold & Vibrant", 
              description: "Bright, saturated, statement colors",
              colors: ["bg-pink-500", "bg-indigo-500", "bg-emerald-500"]
            }
          ].map((option) => {
            const isSelected = formData.colors === option.value;
            return (
              <label 
                key={option.value}
                className="cursor-pointer"
                data-testid={`option-colors-${option.value}`}
              >
                <input 
                  type="radio" 
                  name="colors" 
                  value={option.value} 
                  className="hidden"
                  onChange={(e) => handleOptionSelect("colors", e.target.value)}
                />
                <div className={`border-2 rounded-lg p-6 hover:border-primary hover:bg-blue-50 transition-all duration-200 ${
                  isSelected ? "border-primary bg-blue-50" : "border-gray-200"
                }`}>
                  <div className="flex items-center mb-3">
                    <div className="flex space-x-1 mr-3">
                      {option.colors.map((color, idx) => (
                        <div key={idx} className={`w-4 h-4 rounded ${color}`} />
                      ))}
                    </div>
                    <h4 className="font-semibold text-gray-900">{option.title}</h4>
                  </div>
                  <p className="text-sm text-gray-500">{option.description}</p>
                </div>
              </label>
            );
          })}
        </div>
        
        <div>
          <Label className="text-sm font-semibold text-gray-700 mb-2">Specific color preferences (optional)</Label>
          <Input 
            value={formData.specificColors || ""}
            onChange={(e) => updateFormData({ specificColors: e.target.value })}
            placeholder="e.g., Navy blue accents, natural wood tones, brass details"
            data-testid="input-specific-colors"
          />
        </div>
        
        <div className="flex justify-between mt-8">
          <Button variant="ghost" onClick={onPrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <Button onClick={onNext} data-testid="button-next">
            Next <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  if (step === 5) {
    const featureCategories = [
      {
        title: "Sustainability Features",
        features: [
          { value: "solar", label: "Solar panels" },
          { value: "green-roof", label: "Green roof" },
          { value: "rainwater", label: "Rainwater collection" },
          { value: "energy-efficient", label: "Energy efficiency" },
          { value: "natural-materials", label: "Natural materials" },
          { value: "living-walls", label: "Living walls" }
        ]
      },
      {
        title: "Technology Integration",
        features: [
          { value: "smart-home", label: "Smart home systems" },
          { value: "automation", label: "Automation" },
          { value: "security", label: "Security systems" },
          { value: "av-systems", label: "A/V systems" },
          { value: "lighting-control", label: "Lighting control" },
          { value: "climate-control", label: "Climate control" }
        ]
      },
      {
        title: "Accessibility Features",
        features: [
          { value: "wheelchair-access", label: "Wheelchair accessible" },
          { value: "universal-design", label: "Universal design" },
          { value: "aging-in-place", label: "Aging in place" }
        ]
      }
    ];

    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Additional features and customizations</h3>
          <p className="text-gray-600">Select any additional features or specific elements you'd like included</p>
        </div>
        
        <div className="space-y-6">
          {featureCategories.map((category, categoryIdx) => (
            <div key={categoryIdx}>
              <h4 className="font-semibold text-gray-900 mb-3">{category.title}</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {category.features.map((feature) => (
                  <div key={feature.value} className="flex items-center space-x-2">
                    <Checkbox 
                      id={feature.value}
                      checked={(formData.features || []).includes(feature.value)}
                      onCheckedChange={(checked) => handleFeatureToggle(feature.value, checked as boolean)}
                      data-testid={`checkbox-feature-${feature.value}`}
                    />
                    <Label htmlFor={feature.value} className="text-sm cursor-pointer">
                      {feature.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          ))}
          
          <div>
            <Label className="text-sm font-semibold text-gray-700 mb-2">Additional Notes</Label>
            <Textarea 
              value={formData.additionalNotes || ""}
              onChange={(e) => updateFormData({ additionalNotes: e.target.value })}
              rows={3}
              placeholder="Any other specific requirements, inspirations, or details we should consider?"
              data-testid="textarea-additional-notes"
            />
          </div>
        </div>
        
        <div className="flex justify-between mt-8">
          <Button variant="ghost" onClick={onPrev} data-testid="button-prev">
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <Button onClick={onNext} data-testid="button-next">
            Review <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    );
  }

  return null;
}
