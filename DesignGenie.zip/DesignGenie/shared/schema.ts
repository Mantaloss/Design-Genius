import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const designProjects = pgTable("design_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectName: text("project_name").notNull(),
  projectType: text("project_type").notNull(),
  style: text("style").notNull(),
  colors: text("colors").notNull(),
  description: text("description"),
  budget: text("budget"),
  timeline: text("timeline"),
  specialRequirements: text("special_requirements"),
  specificColors: text("specific_colors"),
  features: jsonb("features").$type<string[]>().default([]),
  additionalNotes: text("additional_notes"),
  generatedImageUrl: text("generated_image_url"),
  designDescription: text("design_description"),
  designExplanation: text("design_explanation"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDesignProjectSchema = createInsertSchema(designProjects).omit({
  id: true,
  createdAt: true,
});

export const designProjectFormSchema = insertDesignProjectSchema.extend({
  projectName: z.string().min(1, "Project name is required"),
  projectType: z.string().min(1, "Project type is required"),
  style: z.string().min(1, "Style preference is required"),
  colors: z.string().min(1, "Color preference is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDesignProject = z.infer<typeof insertDesignProjectSchema>;
export type DesignProject = typeof designProjects.$inferSelect;
export type DesignProjectForm = z.infer<typeof designProjectFormSchema>;
