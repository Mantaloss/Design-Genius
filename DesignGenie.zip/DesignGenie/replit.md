# DesignGenius - AI Design Generator

## Overview

DesignGenius is a full-stack web application that generates custom design images using AI. Users complete a multi-step questionnaire about their design preferences (project type, style, colors, features) and receive AI-generated images with detailed descriptions. The application serves architects, interior designers, and creative professionals who need visual inspiration for their projects.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design system
- **Routing**: Wouter for client-side routing with three main routes: home, questionnaire, and results
- **State Management**: TanStack React Query for server state management and caching
- **UI Components**: Radix UI primitives with custom styling for accessibility and consistency
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless hosting
- **API Design**: RESTful endpoints for creating projects and generating designs
- **Error Handling**: Centralized error middleware with structured error responses
- **Development**: Hot module replacement with Vite middleware integration

### Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon for production scalability
- **Development Storage**: In-memory storage implementation for development/testing
- **Schema Management**: Drizzle migrations for database version control
- **Data Models**: 
  - Users table for basic authentication
  - Design projects table storing questionnaire responses and generated content
  - JSON fields for flexible feature arrays and metadata

### Authentication and Authorization
- **Current State**: Basic user schema defined but authentication not fully implemented
- **Session Management**: Express sessions configured with PostgreSQL store
- **Future Implementation**: Ready for username/password authentication system

## External Dependencies

### AI Services
- **Anthropic Claude API**: Primary integration for design generation
  - Claude Sonnet 4 (claude-sonnet-4-20250514) for generating detailed design descriptions and explanations
  - SVG placeholder generation for visual design concepts
  - Custom prompt engineering for architectural and design-specific outputs
  - Note: Image generation handled via SVG placeholders since Claude doesn't provide image generation

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting for production
- **Connection**: Uses @neondatabase/serverless for optimized serverless connections

### UI and Styling Dependencies
- **shadcn/ui**: Component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Radix UI**: Accessible component primitives for complex UI interactions
- **Lucide Icons**: Icon library for consistent iconography

### Development Tools
- **Vite**: Build tool with TypeScript support and hot reload
- **ESBuild**: Fast bundling for production builds
- **Drizzle Kit**: Database migration and schema management tools
- **TanStack React Query**: Server state management with caching and synchronization

### Validation and Type Safety
- **Zod**: Runtime type validation for form data and API payloads
- **TypeScript**: End-to-end type safety from database to frontend
- **Drizzle Zod**: Auto-generated Zod schemas from database schema