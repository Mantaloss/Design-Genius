import { type User, type InsertUser, type DesignProject, type InsertDesignProject } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createDesignProject(project: InsertDesignProject): Promise<DesignProject>;
  getDesignProject(id: string): Promise<DesignProject | undefined>;
  updateDesignProject(id: string, updates: Partial<DesignProject>): Promise<DesignProject | undefined>;
  getUserProjects(userId?: string): Promise<DesignProject[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private designProjects: Map<string, DesignProject>;

  constructor() {
    this.users = new Map();
    this.designProjects = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createDesignProject(insertProject: InsertDesignProject): Promise<DesignProject> {
    const id = randomUUID();
    const project: DesignProject = { 
      ...insertProject, 
      id,
      description: insertProject.description || null,
      budget: insertProject.budget || null,
      timeline: insertProject.timeline || null,
      specialRequirements: insertProject.specialRequirements || null,
      specificColors: insertProject.specificColors || null,
      additionalNotes: insertProject.additionalNotes || null,
      generatedImageUrl: insertProject.generatedImageUrl || null,
      designDescription: insertProject.designDescription || null,
      designExplanation: insertProject.designExplanation || null,
      features: insertProject.features ? [...insertProject.features] : null,
      createdAt: new Date()
    };
    this.designProjects.set(id, project);
    return project;
  }

  async getDesignProject(id: string): Promise<DesignProject | undefined> {
    return this.designProjects.get(id);
  }

  async updateDesignProject(id: string, updates: Partial<DesignProject>): Promise<DesignProject | undefined> {
    const existing = this.designProjects.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.designProjects.set(id, updated);
    return updated;
  }

  async getUserProjects(userId?: string): Promise<DesignProject[]> {
    // For this demo, return all projects since we don't have user authentication
    return Array.from(this.designProjects.values()).sort(
      (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }
}

export const storage = new MemStorage();
