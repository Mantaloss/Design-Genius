import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDesignProjectSchema, designProjectFormSchema } from "@shared/schema";
import { generateDesignImage, generateDesignDescription } from "./services/claude";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create a new design project
  app.post("/api/design-projects", async (req, res) => {
    try {
      const validatedData = designProjectFormSchema.parse(req.body);
      
      const project = await storage.createDesignProject({
        ...validatedData,
        generatedImageUrl: null,
        designDescription: null,
        designExplanation: null,
      });
      
      res.json(project);
    } catch (error: any) {
      console.error("Error creating design project:", error);
      res.status(400).json({ 
        message: error.message || "Failed to create design project" 
      });
    }
  });

  // Generate design for a project
  app.post("/api/design-projects/:id/generate", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getDesignProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Generate image
      const imageResult = await generateDesignImage({
        projectType: project.projectType,
        style: project.style,
        colors: project.colors,
        description: project.description || undefined,
        budget: project.budget || undefined,
        timeline: project.timeline || undefined,
        specialRequirements: project.specialRequirements || undefined,
        specificColors: project.specificColors || undefined,
        features: project.features || [],
        additionalNotes: project.additionalNotes || undefined,
        projectName: project.projectName,
      });

      // Generate descriptions
      const descriptionResult = await generateDesignDescription({
        projectType: project.projectType,
        style: project.style,
        colors: project.colors,
        description: project.description || undefined,
        budget: project.budget || undefined,
        timeline: project.timeline || undefined,
        specialRequirements: project.specialRequirements || undefined,
        specificColors: project.specificColors || undefined,
        features: project.features || [],
        additionalNotes: project.additionalNotes || undefined,
        projectName: project.projectName,
      }, imageResult.url);

      // Update project with generated content
      const updatedProject = await storage.updateDesignProject(id, {
        generatedImageUrl: imageResult.url,
        designDescription: descriptionResult.description,
        designExplanation: descriptionResult.explanation,
      });

      res.json(updatedProject);
    } catch (error: any) {
      console.error("Error generating design:", error);
      res.status(500).json({ 
        message: error.message || "Failed to generate design" 
      });
    }
  });

  // Get a specific design project
  app.get("/api/design-projects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getDesignProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error: any) {
      console.error("Error fetching project:", error);
      res.status(500).json({ 
        message: error.message || "Failed to fetch project" 
      });
    }
  });

  // Get all design projects
  app.get("/api/design-projects", async (req, res) => {
    try {
      const projects = await storage.getUserProjects();
      res.json(projects);
    } catch (error: any) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ 
        message: error.message || "Failed to fetch projects" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
